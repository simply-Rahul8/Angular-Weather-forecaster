import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { bootstrapApplication } from '@angular/platform-browser';
import { WeatherService } from './services/weather.service';
import { WeatherSearchComponent } from './components/weather-search.component';
import { CurrentWeatherComponent } from './components/current-weather.component';
import { ForecastComponent } from './components/forecast.component';
import { WeatherData, DailyForecast } from './models/weather.model';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HttpClientModule,
    WeatherSearchComponent,
    CurrentWeatherComponent,
    ForecastComponent
  ],
  providers: [WeatherService],
  template: `
    <div class="app-container">
      <header class="app-header">
        <h1 class="app-title">
          <span class="weather-icon">🌤️</span>
          Weather Dashboard
        </h1>
        <p class="app-subtitle">Get real-time weather information for any city</p>
      </header>

      <main class="app-main">
        <app-weather-search (search)="searchWeather($event)"></app-weather-search>

        <div *ngIf="loading" class="loading-container">
          <div class="loading-spinner"></div>
          <p>Fetching weather data...</p>
        </div>

        <div *ngIf="error" class="error-container">
          <div class="error-icon">⚠️</div>
          <h3>{{ error.title }}</h3>
          <p>{{ error.message }}</p>
          <button (click)="clearError()" class="retry-button">Try Again</button>
        </div>

        <div *ngIf="!loading && !error && currentWeather">
          <app-current-weather
            [weatherData]="currentWeather"
            [units]="units">
          </app-current-weather>

          <app-forecast
            [forecastData]="forecast"
            [units]="units">
          </app-forecast>
        </div>

        <div *ngIf="!loading && !error && !currentWeather" class="welcome-container">
          <div class="welcome-icon">🌍</div>
          <h2>Welcome to Weather Dashboard</h2>
          <p>Search for a city to get started with real-time weather information</p>
          <div class="api-notice">
            <h4>🔑 API Key Required</h4>
            <p>To use this app, you'll need a free API key from <a href="https://openweathermap.org/api" target="_blank">OpenWeatherMap</a></p>
            <p>Replace 'YOUR_API_KEY_HERE' in the weather service with your actual API key.</p>
          </div>
        </div>
      </main>

      <footer class="app-footer">
        <p>Weather data provided by <a href="https://openweathermap.org" target="_blank">OpenWeatherMap</a></p>
      </footer>
    </div>
  `,
  styles: [`
    .app-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 2rem 0;
    }

    .app-header {
      text-align: center;
      color: white;
      margin-bottom: 3rem;
    }

    .app-title {
      font-size: 3rem;
      font-weight: 300;
      margin: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 1rem;
    }

    .weather-icon {
      font-size: 3.5rem;
    }

    .app-subtitle {
      font-size: 1.1rem;
      margin: 1rem 0 0 0;
      opacity: 0.9;
    }

    .app-main {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 2rem;
    }

    .loading-container {
      text-align: center;
      color: white;
      padding: 3rem;
    }

    .loading-spinner {
      width: 50px;
      height: 50px;
      border: 4px solid rgba(255, 255, 255, 0.3);
      border-top: 4px solid white;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin: 0 auto 1rem auto;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .error-container {
      background: white;
      border-radius: 15px;
      padding: 2rem;
      text-align: center;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      max-width: 500px;
      margin: 0 auto;
      border-left: 4px solid #ef4444;
    }

    .error-icon {
      font-size: 3rem;
      margin-bottom: 1rem;
    }

    .error-container h3 {
      color: #dc2626;
      margin: 0 0 1rem 0;
    }

    .error-container p {
      color: #6b7280;
      margin: 0 0 2rem 0;
    }

    .retry-button {
      background: #3b82f6;
      color: white;
      border: none;
      padding: 0.75rem 2rem;
      border-radius: 25px;
      cursor: pointer;
      font-size: 1rem;
      transition: all 0.3s ease;
    }

    .retry-button:hover {
      background: #2563eb;
      transform: translateY(-1px);
    }

    .welcome-container {
      background: white;
      border-radius: 20px;
      padding: 3rem;
      text-align: center;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      max-width: 600px;
      margin: 0 auto;
    }

    .welcome-icon {
      font-size: 4rem;
      margin-bottom: 1rem;
    }

    .welcome-container h2 {
      color: #374151;
      margin: 0 0 1rem 0;
    }

    .welcome-container p {
      color: #6b7280;
      margin: 0 0 2rem 0;
      font-size: 1.1rem;
    }

    .api-notice {
      background: #fef3c7;
      border: 1px solid #f59e0b;
      border-radius: 10px;
      padding: 1.5rem;
      margin-top: 2rem;
    }

    .api-notice h4 {
      color: #92400e;
      margin: 0 0 1rem 0;
    }

    .api-notice p {
      color: #92400e;
      margin: 0 0 0.5rem 0;
      font-size: 0.9rem;
    }

    .api-notice a {
      color: #3b82f6;
      text-decoration: none;
    }

    .api-notice a:hover {
      text-decoration: underline;
    }

    .app-footer {
      text-align: center;
      color: rgba(255, 255, 255, 0.8);
      margin-top: 3rem;
      padding: 2rem;
    }

    .app-footer a {
      color: rgba(255, 255, 255, 0.9);
      text-decoration: none;
    }

    .app-footer a:hover {
      text-decoration: underline;
    }

    @media (max-width: 768px) {
      .app-container {
        padding: 1rem 0;
      }

      .app-title {
        font-size: 2rem;
      }

      .weather-icon {
        font-size: 2.5rem;
      }

      .app-main {
        padding: 0 1rem;
      }

      .welcome-container,
      .error-container {
        margin: 0 1rem;
        padding: 2rem;
      }
    }
  `]
})
export class App implements OnInit {
  currentWeather: WeatherData | null = null;
  forecast: DailyForecast[] = [];
  loading = false;
  error: { title: string; message: string } | null = null;
  units = 'metric';

  constructor(private weatherService: WeatherService) {}

  ngOnInit() {
    // Load default city (optional)
    // this.searchWeather('London');
  }

  searchWeather(city: string) {
    this.loading = true;
    this.error = null;
    this.currentWeather = null;
    this.forecast = [];

    // Check if API key is configured
    if (this.weatherService['API_KEY'] === '40faaa24b9b10daef6ec62b32d7182d0') {
      this.loading = false;
      return;
    }

    // Get current weather
    this.weatherService.getCurrentWeather(city, this.units).subscribe({
      next: (data) => {
        this.currentWeather = data;
        this.getForecast(city);
      },
      error: (err) => {
        this.loading = false;
        this.handleError(err);
      }
    });
  }

  private getForecast(city: string) {
    this.weatherService.getForecast(city, this.units).subscribe({
      next: (data) => {
        this.forecast = data;
        this.loading = false;
      },
      error: (err) => {
        this.loading = false;
        this.handleError(err);
      }
    });
  }

  private handleError(err: any) {
    console.error('Weather API Error:', err);
    
    if (err.status === 404) {
      this.error = {
        title: 'City Not Found',
        message: 'The city you searched for could not be found. Please check the spelling and try again.'
      };
    } else if (err.status === 401) {
      this.error = {
        title: 'Invalid API Key',
        message: 'The API key is invalid or expired. Please check your OpenWeatherMap API key.'
      };
    } else if (err.status === 0) {
      this.error = {
        title: 'Network Error',
        message: 'Unable to connect to the weather service. Please check your internet connection.'
      };
    } else {
      this.error = {
        title: 'Weather Service Error',
        message: 'An error occurred while fetching weather data. Please try again later.'
      };
    }
  }

  clearError() {
    this.error = null;
  }
}

bootstrapApplication(App, {
  providers: [HttpClientModule]
});
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { WeatherData, ForecastData, DailyForecast } from '../models/weather.model';

@Injectable({
  providedIn: 'root'
})
export class WeatherService {
  private readonly API_KEY = '40faaa24b9b10daef6ec62b32d7182d0';
  private readonly BASE_URL = 'https://api.openweathermap.org/data/2.5';

  constructor(private http: HttpClient) {}

  getCurrentWeather(city: string, units: string = 'metric'): Observable<WeatherData> {
    const url = `${this.BASE_URL}/weather?q=${city}&appid=${this.API_KEY}&units=${units}`;
    return this.http.get<WeatherData>(url);
  }

  getForecast(city: string, units: string = 'metric'): Observable<DailyForecast[]> {
    const url = `${this.BASE_URL}/forecast?q=${city}&appid=${this.API_KEY}&units=${units}`;
    return this.http.get<ForecastData>(url).pipe(
      map(data => this.processForecastData(data))
    );
  }

  private processForecastData(data: ForecastData): DailyForecast[] {
    const dailyData: { [key: string]: any } = {};

    data.list.forEach(item => {
      const date = new Date(item.dt * 1000);
      const dateKey = date.toDateString();

      if (!dailyData[dateKey]) {
        dailyData[dateKey] = {
          date: date,
          temps: [],
          descriptions: [],
          icons: [],
          humidities: [],
          windSpeeds: []
        };
      }

      dailyData[dateKey].temps.push(item.main.temp);
      dailyData[dateKey].descriptions.push(item.weather[0].description);
      dailyData[dateKey].icons.push(item.weather[0].icon);
      dailyData[dateKey].humidities.push(item.main.humidity);
      dailyData[dateKey].windSpeeds.push(item.wind.speed);
    });

    return Object.values(dailyData).slice(0, 5).map((day: any) => ({
      date: day.date,
      temp_min: Math.min(...day.temps),
      temp_max: Math.max(...day.temps),
      description: day.descriptions[Math.floor(day.descriptions.length / 2)],
      icon: day.icons[Math.floor(day.icons.length / 2)],
      humidity: Math.round(day.humidities.reduce((a: number, b: number) => a + b, 0) / day.humidities.length),
      windSpeed: Math.round(day.windSpeeds.reduce((a: number, b: number) => a + b, 0) / day.windSpeeds.length * 10) / 10
    }));
  }

  getWeatherIconUrl(icon: string): string {
    return `https://openweathermap.org/img/wn/${icon}@2x.png`;
  }
}
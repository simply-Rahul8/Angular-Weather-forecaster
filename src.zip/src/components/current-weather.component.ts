import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WeatherData } from '../models/weather.model';

@Component({
  selector: 'app-current-weather',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="weather-card" *ngIf="weatherData">
      <div class="weather-header">
        <div class="location">
          <h2>{{ weatherData.name }}, {{ weatherData.sys.country }}</h2>
          <p class="date">{{ getCurrentDate() }}</p>
        </div>
        <div class="units-toggle">
          <button
            [class.active]="units === 'metric'"
            (click)="toggleUnits('metric')"
          >°C</button>
          <button
            [class.active]="units === 'imperial'"
            (click)="toggleUnits('imperial')"
          >°F</button>
        </div>
      </div>

      <div class="weather-main">
        <div class="temperature-section">
          <img
            [src]="getWeatherIcon(weatherData.weather[0].icon)"
            [alt]="weatherData.weather[0].description"
            class="weather-icon"
          >
          <div class="temperature">
            <span class="temp-value">{{ Math.round(weatherData.main.temp) }}</span>
            <span class="temp-unit">{{ units === 'metric' ? '°C' : '°F' }}</span>
          </div>
        </div>
        <div class="weather-description">
          <h3>{{ weatherData.weather[0].main }}</h3>
          <p>{{ weatherData.weather[0].description | titlecase }}</p>
          <p class="feels-like">
            Feels like {{ Math.round(weatherData.main.feels_like) }}{{ units === 'metric' ? '°C' : '°F' }}
          </p>
        </div>
      </div>

      <div class="weather-details">
        <div class="detail-item">
          <div class="detail-icon">💧</div>
          <div class="detail-info">
            <span class="detail-label">Humidity</span>
            <span class="detail-value">{{ weatherData.main.humidity }}%</span>
          </div>
        </div>
        <div class="detail-item">
          <div class="detail-icon">🌪️</div>
          <div class="detail-info">
            <span class="detail-label">Wind Speed</span>
            <span class="detail-value">{{ weatherData.wind.speed }} {{ units === 'metric' ? 'm/s' : 'mph' }}</span>
          </div>
        </div>
        <div class="detail-item">
          <div class="detail-icon">🌡️</div>
          <div class="detail-info">
            <span class="detail-label">Pressure</span>
            <span class="detail-value">{{ weatherData.main.pressure }} hPa</span>
          </div>
        </div>
        <div class="detail-item">
          <div class="detail-icon">👁️</div>
          <div class="detail-info">
            <span class="detail-label">Range</span>
            <span class="detail-value">
              {{ Math.round(weatherData.main.temp_min) }}° / {{ Math.round(weatherData.main.temp_max) }}°
            </span>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .weather-card {
      background: linear-gradient(135deg, #74b9ff 0%, #0984e3 100%);
      border-radius: 20px;
      padding: 2rem;
      color: white;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      margin-bottom: 2rem;
    }

    .weather-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 2rem;
    }

    .location h2 {
      margin: 0;
      font-size: 1.5rem;
      font-weight: 600;
    }

    .date {
      margin: 0.5rem 0 0 0;
      opacity: 0.8;
      font-size: 0.9rem;
    }

    .units-toggle {
      display: flex;
      background: rgba(255, 255, 255, 0.2);
      border-radius: 20px;
      overflow: hidden;
    }

    .units-toggle button {
      padding: 0.5rem 1rem;
      border: none;
      background: transparent;
      color: white;
      cursor: pointer;
      transition: all 0.3s ease;
      font-size: 0.9rem;
    }

    .units-toggle button.active {
      background: rgba(255, 255, 255, 0.3);
    }

    .weather-main {
      display: flex;
      align-items: center;
      margin-bottom: 2rem;
      gap: 2rem;
    }

    .temperature-section {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .weather-icon {
      width: 80px;
      height: 80px;
    }

    .temperature {
      display: flex;
      align-items: flex-start;
    }

    .temp-value {
      font-size: 4rem;
      font-weight: 300;
      line-height: 1;
    }

    .temp-unit {
      font-size: 1.5rem;
      margin-top: 0.5rem;
      opacity: 0.8;
    }

    .weather-description h3 {
      margin: 0 0 0.5rem 0;
      font-size: 1.2rem;
    }

    .weather-description p {
      margin: 0;
      opacity: 0.9;
    }

    .feels-like {
      margin-top: 0.5rem !important;
      font-size: 0.9rem;
      opacity: 0.8 !important;
    }

    .weather-details {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
    }

    .detail-item {
      display: flex;
      align-items: center;
      gap: 1rem;
      background: rgba(255, 255, 255, 0.1);
      padding: 1rem;
      border-radius: 10px;
    }

    .detail-icon {
      font-size: 1.5rem;
    }

    .detail-info {
      display: flex;
      flex-direction: column;
    }

    .detail-label {
      font-size: 0.8rem;
      opacity: 0.8;
      margin-bottom: 0.2rem;
    }

    .detail-value {
      font-weight: 600;
    }

    @media (max-width: 768px) {
      .weather-card {
        margin: 0 1rem 2rem 1rem;
        padding: 1.5rem;
      }

      .weather-header {
        flex-direction: column;
        gap: 1rem;
      }

      .weather-main {
        flex-direction: column;
        text-align: center;
        gap: 1rem;
      }

      .weather-details {
        grid-template-columns: 1fr;
      }

      .temp-value {
        font-size: 3rem;
      }
    }
  `]
})
export class CurrentWeatherComponent {
  @Input() weatherData!: WeatherData;
  @Input() units = 'metric';

  Math = Math;

  toggleUnits(newUnits: string) {
    // This would typically emit an event to parent component
    console.log('Toggle units to:', newUnits);
  }

  getCurrentDate(): string {
    return new Date().toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }

  getWeatherIcon(icon: string): string {
    return `https://openweathermap.org/img/wn/${icon}@2x.png`;
  }
}
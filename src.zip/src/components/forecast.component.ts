import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DailyForecast } from '../models/weather.model';

@Component({
  selector: 'app-forecast',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="forecast-container" *ngIf="forecastData && forecastData.length">
      <h3 class="forecast-title">5-Day Forecast</h3>
      <div class="forecast-grid">
        <div
          *ngFor="let day of forecastData; trackBy: trackByDate"
          class="forecast-card"
        >
          <div class="forecast-date">
            <span class="day-name">{{ getDayName(day.date) }}</span>
            <span class="date">{{ getFormattedDate(day.date) }}</span>
          </div>
          <img
            [src]="getWeatherIcon(day.icon)"
            [alt]="day.description"
            class="forecast-icon"
          >
          <div class="forecast-temp">
            <span class="temp-max">{{ Math.round(day.temp_max) }}°</span>
            <span class="temp-min">{{ Math.round(day.temp_min) }}°</span>
          </div>
          <p class="forecast-description">{{ day.description | titlecase }}</p>
          <div class="forecast-details">
            <div class="detail">
              <span class="detail-icon">💧</span>
              <span>{{ day.humidity }}%</span>
            </div>
            <div class="detail">
              <span class="detail-icon">🌪️</span>
              <span>{{ day.windSpeed }} {{ units === 'metric' ? 'm/s' : 'mph' }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .forecast-container {
      margin-top: 2rem;
    }

    .forecast-title {
      text-align: center;
      margin-bottom: 1.5rem;
      color: #374151;
      font-size: 1.5rem;
      font-weight: 600;
    }

    .forecast-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
      max-width: 1200px;
      margin: 0 auto;
    }

    .forecast-card {
      background: white;
      border-radius: 15px;
      padding: 1.5rem;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      text-align: center;
      transition: all 0.3s ease;
      border: 1px solid #e5e7eb;
    }

    .forecast-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    }

    .forecast-date {
      margin-bottom: 1rem;
    }

    .day-name {
      display: block;
      font-weight: 600;
      color: #374151;
      font-size: 1rem;
    }

    .date {
      display: block;
      color: #6b7280;
      font-size: 0.8rem;
      margin-top: 0.2rem;
    }

    .forecast-icon {
      width: 60px;
      height: 60px;
      margin: 0 auto 1rem auto;
      display: block;
    }

    .forecast-temp {
      margin-bottom: 1rem;
    }

    .temp-max {
      font-size: 1.2rem;
      font-weight: 600;
      color: #374151;
      margin-right: 0.5rem;
    }

    .temp-min {
      font-size: 1rem;
      color: #6b7280;
    }

    .forecast-description {
      margin: 0 0 1rem 0;
      color: #6b7280;
      font-size: 0.9rem;
    }

    .forecast-details {
      display: flex;
      justify-content: space-around;
      margin-top: 1rem;
      padding-top: 1rem;
      border-top: 1px solid #e5e7eb;
    }

    .detail {
      display: flex;
      align-items: center;
      gap: 0.3rem;
      font-size: 0.8rem;
      color: #6b7280;
    }

    .detail-icon {
      font-size: 1rem;
    }

    @media (max-width: 768px) {
      .forecast-container {
        margin: 2rem 1rem 0 1rem;
      }

      .forecast-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
      }

      .forecast-card {
        padding: 1rem;
      }
    }

    @media (max-width: 480px) {
      .forecast-grid {
        grid-template-columns: repeat(2, 1fr);
      }
    }
  `]
})
export class ForecastComponent {
  @Input() forecastData!: DailyForecast[];
  @Input() units = 'metric';

  Math = Math;

  trackByDate(index: number, item: DailyForecast): string {
    return item.date.toISOString();
  }

  getDayName(date: Date): string {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    }
    if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow';
    }
    return date.toLocaleDateString('en-US', { weekday: 'short' });
  }

  getFormattedDate(date: Date): string {
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  }

  getWeatherIcon(icon: string): string {
    return `https://openweathermap.org/img/wn/${icon}@2x.png`;
  }
}
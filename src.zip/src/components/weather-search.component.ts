import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-weather-search',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="search-container">
      <div class="search-box">
        <input
          type="text"
          [(ngModel)]="searchQuery"
          (keyup.enter)="onSearch()"
          placeholder="Enter city name..."
          class="search-input"
        >
        <button
          (click)="onSearch()"
          [disabled]="!searchQuery.trim()"
          class="search-button"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
        </button>
      </div>
    </div>
  `,
  styles: [`
    .search-container {
      margin-bottom: 2rem;
    }

    .search-box {
      display: flex;
      max-width: 500px;
      margin: 0 auto;
      border-radius: 25px;
      overflow: hidden;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      background: white;
    }

    .search-input {
      flex: 1;
      padding: 1rem 1.5rem;
      border: none;
      outline: none;
      font-size: 1rem;
      background: transparent;
    }

    .search-input::placeholder {
      color: #6b7280;
    }

    .search-button {
      padding: 1rem 1.5rem;
      border: none;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .search-button:hover:not(:disabled) {
      background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
      transform: translateY(-1px);
    }

    .search-button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    @media (max-width: 768px) {
      .search-box {
        margin: 0 1rem;
      }
    }
  `]
})
export class WeatherSearchComponent {
  @Output() search = new EventEmitter<string>();
  searchQuery = '';

  onSearch() {
    if (this.searchQuery.trim()) {
      this.search.emit(this.searchQuery.trim());
    }
  }
}